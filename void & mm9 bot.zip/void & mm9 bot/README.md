1 - eng : first you should go to (info.json) and enter your bot TOKEN

1 - persian : aval az hame bayad berid to file (info.json) va token bot ro vared konid
---------------------------------------------------------------
2 - eng : this fastest nuke bot and most danger bot you shouildnt try this at your main server 

2 - persian : bot be elat dashtan bug to server khodeton test nakonid 
---------------------------------------------------------------
3 - eng : and you can use (nuke) command to nuke the server you want 

3 - persian : baraye nuke az command (nuke) estefade konid
--------------------------------------------------------------

our discord servers :
{
    UNIVERSE : https://discord.gg/r75Wbs7YCh
    MM9 : https://discord.gg/S3Qe5ck6Ny
}