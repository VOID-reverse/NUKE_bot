
module.exports = {
    name: 'ping',
    description: "just pong",
    async execute(message, args, Discord) {




        message.channel.send('PING : ....').then(msg =>{
            const ping = msg.createdTimestamp - message.createdTimestamp;
            msg.edit(`PING : ${ping} ms`)
            message.channel.send('salam', {
                tts: true
            })
        })
        // const pembed = new Discord.MessageEmbed()
        //     .setColor('#59ff00')
        //     .setTitle('abol rakoni hanoz zendast XD')
        //     .setDescription(`<@${message.author.id}>` + '`be che jorat fara khandi abol ra :0`',)
        //     .setURL('https://discord.com/channels/876059669297254441/876430399935508491')
        //     .setImage('https://cdn.discordapp.com/attachments/882187986626834462/933442705978183680/IMG-20220119-WA0000.jpeg')
        //     .setFooter('Dev : VOID')
        // const ree = '🔴';
        
        // let fdb = new MessageButton()
        //     .setStyle('red')
        //     .setLabel('ABOL')
        //     .setID('cf')

        // let sdb = new MessageButton()
        //     .setStyle('green')
        //     .setLabel('OK')
        //     .setID('df')

        // let row1 = new button.MessageActionRow()
        //     .addCommponent(fdb)
        //     .addCommponent(sdb)

        // message.channel.send(pembed,sdb,fdb);
        
    }
}
