module.exports = {
    name: 'dc',
    description: 'disconnect voice',
    async execute(message, args, Discord) {
        if (message.member.roles.cache.has('935935661423341568') || message.member.roles.cache.has('935935667207295006') || message.member.roles.cache.has('935935662442557510')
            || message.member.roles.cache.has('935935664879444048') || message.member.roles.cache.has('935935663528878090')
        ) {
            const voice_channel = message.member.voice.channel;
            if (!message.guild.me.voice.channel) return message.channel.send("I'm not in a voice channel"); //If the bot is not in a voice channel, then return a message
            message.guild.me.voice.channel.leave();
            let dcEmbed = new Discord.MessageEmbed()
                .setAuthor(`${message.guild.name}`)
                .setTitle('DISCONNECTED')
                .setDescription(`leave ` + '`' + `${voice_channel.name}` + '`')
                .setColor('RANDOM')
                message.channel.send(dcEmbed)
        } else {
            message.reply('perm nadari')
        }
    }
}